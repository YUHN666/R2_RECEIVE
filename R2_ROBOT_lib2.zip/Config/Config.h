#ifndef _CONFIG_H_
#define _CONFIG_H_
#include "main.h"
#include "zigbee.h"
#include "usart.h"
#include "COMMS_task.h"



void Config_Init(void);
#endif